/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
#include "fonts.h"      // 폰트 라이브러리
#include "ssd1306.h"    // SSD1306 OLED 드라이버
#include <stdio.h>

/* Private typedef -----------------------------------------------------------*/
/* HX711 핀 설정 */
#define DT_PIN GPIO_PIN_0
#define DT_PORT GPIOA
#define SCK_PIN GPIO_PIN_1
#define SCK_PORT GPIOB

/* Private variables ---------------------------------------------------------*/
char strCopy[15];         // OLED 출력용 문자열 버퍼
uint32_t tare = 8015587;  // 초기 영점 값
float knownOriginal = 1500000;  // 기준 무게 (1.5kg)
float knownHX711 = -2147483648; // 기준 ADC 값
int weight;               // 측정된 무게 값 (mg)

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/**
  * @brief 마이크로초 단위 딜레이 함수 (TIM2 사용)
  * @param delay : 딜레이 시간 (마이크로초)
  */
void microDelay(uint16_t delay)
{
  __HAL_TIM_SET_COUNTER(&htim2, 0);
  while (__HAL_TIM_GET_COUNTER(&htim2) < delay);
}

/**
  * @brief HX711에서 24비트 데이터를 읽어오는 함수
  * @retval 24비트 무게 데이터
  */
int32_t getHX711(void)
{
  uint32_t data = 0;
  uint32_t startTime = HAL_GetTick();

  /* 데이터 준비 대기 (DT 핀이 LOW가 될 때까지) */
  while(HAL_GPIO_ReadPin(DT_PORT, DT_PIN) == GPIO_PIN_SET)
  {
    if(HAL_GetTick() - startTime > 200)
      return 0;  // 타임아웃 처리
  }

  /* 24비트 데이터 수신 */
  for(int8_t len=0; len<24 ; len++)
  {
    HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET);
    microDelay(1);
    data = data << 1;
    HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);
    microDelay(1);
    if(HAL_GPIO_ReadPin(DT_PORT, DT_PIN) == GPIO_PIN_SET)
      data++;
  }

  /* 부호 비트 처리 */
  data = data ^ 0x800000;

  /* 추가 클럭 1펄스 전송 */
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET);
  microDelay(1);
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);
  microDelay(1);

  return data;
}

/**
  * @brief 무게 측정 함수
  * @retval 변환된 무게 (mg 단위)
  */
int weigh()
{
  int32_t  total = 0;
  int32_t  samples = 50;
  int milligram;
  float coefficient;

  /* 여러 샘플 평균값 계산 */
  for(uint16_t i=0 ; i<samples ; i++)
  {
      total += getHX711();
  }
  int32_t average = (int32_t)(total / samples);

  /* 기준값을 이용한 무게 변환 */
  coefficient = knownOriginal / knownHX711;
  milligram = (int)(average - tare) * coefficient;

  return milligram;
}

/**
  * @brief  메인 프로그램 시작점
  */
int main(void)
{
  /* STM32 HAL 초기화 */
  HAL_Init();
  SystemClock_Config();

  /* 주변 장치 초기화 */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_I2C3_Init();

  /* SSD1306 OLED 초기화 */
  SSD1306_Init();

  /* TIM2 시작 (마이크로초 딜레이) */
  HAL_TIM_Base_Start(&htim2);

  /* HX711 초기화 시퀀스 */
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_SET);
  HAL_Delay(10);
  HAL_GPIO_WritePin(SCK_PORT, SCK_PIN, GPIO_PIN_RESET);
  HAL_Delay(10);

  /* 무게 측정 루프 */
  while (1)
  {
    weight = weigh(); // mg 단위로 무게 측정

    /* OLED 화면 업데이트 */
    SSD1306_Clear();
    SSD1306_GotoXY(0, 0);
    sprintf(strCopy, "Weight");
    SSD1306_Puts(strCopy, &Font_11x18, 1);

    SSD1306_GotoXY(0, 20);
    sprintf(strCopy, "%d mg", weight);
    SSD1306_Puts(strCopy, &Font_11x18, 1);
    SSD1306_UpdateScreen();
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
